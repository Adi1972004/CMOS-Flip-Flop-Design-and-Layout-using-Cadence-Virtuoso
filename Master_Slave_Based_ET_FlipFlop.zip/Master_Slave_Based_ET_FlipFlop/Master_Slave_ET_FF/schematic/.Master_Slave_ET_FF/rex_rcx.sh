set -e
set -x

rex -dp_comm_string 1,server3.eced.svnit.ac.in,42353 -V -m -pd -I# -tech /tools/cadence/FOUNDRY/analog/180nm/pv/assura/rcx_RF -map p2elayermapfile -N NET -Ply np_rPOLYterm -rP res.mod -mp mprexajXKDu9 np_rM1term::mt1_cut - rPSDcont,1,t rPOLYcont,1,T rNSDcont,1,t - L1T0,1,I

rex -dp_comm_string 2,server3.eced.svnit.ac.in,42353 -V -m -pd -I# -tech /tools/cadence/FOUNDRY/analog/180nm/pv/assura/rcx_RF -map p2elayermapfile -N NET -Ply np_rPOLYterm -rP res.mod -mp mprexa7ncvn9 np_rPOLYterm::poly_cut - PMOS_MOS_27_mgvia,1,z NMOS_MOS_21_mgvia,1,z rPOLYcont,1,x

rexmerge -V -N NET -n mprexa7ncvn9,mprexajXKDu9 -b np_rPOLYterm,np_rM1term -l ,L1T0 np_rPOLYterm.res,np_rM1term.res

